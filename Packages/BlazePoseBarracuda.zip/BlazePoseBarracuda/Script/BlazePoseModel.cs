using Mediapipe.PoseLandmark;

namespace Mediapipe.BlazePose{
    public enum BlazePoseModel{
        lite,
        full
    }
}